//Load Slides
$(window).load(function () {
	$('.preloader').delay(1000).fadeOut("slow");
});

// Background
$(function () {
	jQuery(document).ready(function () {
		$('body').backstretch([
			"images/Background.jpg"
		]);
	});
})